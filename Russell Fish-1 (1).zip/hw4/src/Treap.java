import java.util.Random;

/**
 * Russell Fish
 * I pledge my honor that I have abided by the stevens honor code system
 * param <E> datatype for Treap
 */

public class Treap<E extends Comparable<E>> {

    /**
     * Treap Node class

     * param <E>
     */
    private static class Node<E extends Comparable<E>> {

        // Data fields

        public Node<E> right, left;
        public int priority;
        public E data;

        /**
         * constructor for Treap Node

         * param data is data in Node
         * param      priority, priority of the node
         */
        public Node(E data, int priority) {
            this.data = data;
            this.priority = priority;
            this.right = null;
            this.left = null;
        }



        /**
         * rotates node to right
         * return the new root for rotated node
         */
        private Node<E> rotateRight() {
            Node<E> left = this.left;
            // flip nodes
            this.left = left.right;
            left.right = this;
            // return left Node
            return left;
        }

        /**
         * rotates node to left

         * return the new root for rotated node
         */
        private Node<E> rotateLeft() {
            Node<E> right = this.right;
            this.right = right.left;
            right.left = this;
            return right;
        }
        /**  f
         * overrides toString for Node, printing the data and priority without this function the code will still run however it will wont be correct
         */

        @Override
        public String toString() {
            return "(key="  + this.data.toString( ) + ", priority=" + Integer.toString(this.priority) + ')';
        }
    }

    // Data fields
    private Node<E> root;
    private Random priorityGenerator;


    /**
     * constructor for Treap (no seed)
     */
    public Treap() {
        this.priorityGenerator = new Random();
        this.root = null;
    }

    /**
     * constructor for Treap
     * param seed (long)
     */
    public Treap(long seed) {
        priorityGenerator = new Random(seed);
        root = null;
    }

    /**
     * add a new Node with random priority
     *  key - data in Node
     * return true if added else false
     */
    public boolean add(E key) {
        if (key == null) {
            throw new IllegalArgumentException("ERROR!! KEY IS NULL");
        }
        int numInts = 10;
        boolean result = !(find(key));
        if (result)
            root = add(key, priorityGenerator.nextInt(numInts), root);
        return result;
    }

    /**
     * add new Node with given priority
     * param key, the data in the node
     * param priority, the priority of the node
     * return true if it can be added and false otherwise
     */
    public boolean add (E key, int priority) {
        if (key == null) {
            throw new IllegalArgumentException("Error: the key cannot be NULL");
        }
        boolean result = !(find(key));
        if (result)
            root = add(key, priority, root);
        return result;
    }

    /**
     * add new Node with given priority (helper function)
     * param , the data in the node
     * param priority, the priority of the node
     * return Node<E> of new root
     */
    private Node<E> add(E data, int priority, Node<E> helper) {
        if (helper == null) {
            Node<E> newHelper = new Node<E>(data, priority);
            return newHelper;
        }
        // adding to bst using compare
        int compare = data.compareTo(helper.data);
        if (compare < 0) {
            helper.left = add(data, priority, helper.left);
            /** this where it checks if it's correct if not it rotates
             *
             */
            if (helper.priority < helper.left.priority) {
                return helper.rotateRight();
            }
        } else if (compare > 0) {
            helper.right = add(data, priority, helper.right);
            // rotate left if priority is less
            if (helper.priority < helper.right.priority) {
                return helper.rotateLeft();
            }
        }
        return helper;
    }

    /**
     * finds Node with given key

     * param key - data of Node that needs to be found
     * return true if found, else false
     */
    public boolean find(E key) {
        if (key == null) {
            throw new IllegalArgumentException("key cannot be null");
        }
        return find(root, key);
    }

    /**
     * finds if Node is in a tree
     * this function will find the
     */
    private boolean find(Node<E> root, E key) {

        while (root != null) {
            int comcompare = key.compareTo(root.data);
            if (comcompare > 0) {
                root = root.right;
            } else if (comcompare < 0) {
                root = root.left;
            } else {

                return true;
            }
        }
        return false;
    }

    /**
     * this is my helper funciton
     for the delete function it will check if its null then get into what delete does
     this isso I didn't have to put everything in a boolean
     */
    private Node<E> delete(E key, Node<E> helper) {
        if (helper == null) {
            return null;
        }
        int compare = key.compareTo(helper.data);
        if (compare < 0) {
            helper.left = delete(key, helper.left);
        } else if (compare > 0) {
            helper.right = delete(key, helper.right);
        } else {
            if (helper.left == null && helper.right == null) {
                return null;
            } else if (helper.left == null) {
                helper = helper.right;
            } else if (helper.right == null) {
                helper = helper.left;
            } else {
                if (helper.left.priority > helper.right.priority) {
                    helper = helper.rotateRight();
                    helper.right = delete(key, helper.right);
                } else {
                    helper = helper.rotateLeft();
                    helper.left = delete(key, helper.left);
                }
            }
        }
        return helper;
    }


    /**
     * deletes a node from the Treap
     *
     * @param key, data of the node to be deleted
     * @return true if it can be deleted and false if not
     */
    public boolean delete(E key) {
        if (key == null) {
            throw new IllegalArgumentException("key cannot be null");
        }
        boolean result = find(key);
        if (result)
            root = delete(key, root);
        return result;
    }

    /**
     * creates a String for the Treap
     *
     *
     * @return String Treap
     */
    private String toString(Node<E> hold, int height) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < height; i++) {
            result.append(" ");
        }
        if (hold == null) {
            result.append("null");
        } else {
            result.append(hold.toString());
            result.append("\n");
            result.append(toString(hold.left, height + 1));
            result.append("\n");
            result.append(toString(hold.right, height + 1));
        }
        return result.toString();

    }


    /**
     * creates a Treap String
     *
     * @return String-ed Treap
     */
    @Override
    public String toString() {
        return toString(root, 0) + "\n";
    }




}
